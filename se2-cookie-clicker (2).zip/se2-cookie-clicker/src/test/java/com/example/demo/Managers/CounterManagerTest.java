package com.example.demo.Managers;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

@DisplayName("CounterManager Tests")
class CounterManagerTest {
    
    private CounterManager counterManager;
    
    @BeforeEach
    void setUp() {
        counterManager = CounterManager.getInstance();
        counterManager.setCounter(0); // Reset for each test
    }
    
    @Test
    @DisplayName("Should create singleton instance")
    void testSingletonPattern() {
        CounterManager instance1 = CounterManager.getInstance();
        CounterManager instance2 = CounterManager.getInstance();
        
        assertSame(instance1, instance2, "Both instances should be the same (Singleton)");
    }
    
    @Test
    @DisplayName("Should set and get counter value correctly")
    void testSetAndGetCounter() {
        // Arrange
        long expectedValue = 42L;
        
        // Act
        counterManager.setCounter(expectedValue);
        long actualValue = counterManager.getCounter();
        
        // Assert
        assertEquals(expectedValue, actualValue, "Counter value should match set value");
    }
    
    @Test
    @DisplayName("Should handle zero counter value")
    void testZeroCounterValue() {
        // Act
        counterManager.setCounter(0L);
        
        // Assert
        assertEquals(0L, counterManager.getCounter(), "Counter should handle zero value");
    }
    
    @Test
    @DisplayName("Should handle negative counter values")
    void testNegativeCounterValue() {
        // Act
        counterManager.setCounter(-100L);
        
        // Assert
        assertEquals(-100L, counterManager.getCounter(), "Counter should handle negative values");
    }
    
    @Test
    @DisplayName("Should handle maximum long value")
    void testMaximumCounterValue() {
        // Act
        counterManager.setCounter(Long.MAX_VALUE);
        
        // Assert
        assertEquals(Long.MAX_VALUE, counterManager.getCounter(), "Counter should handle maximum long value");
    }
    
    @Test
    @DisplayName("Should handle minimum long value")
    void testMinimumCounterValue() {
        // Act
        counterManager.setCounter(Long.MIN_VALUE);
        
        // Assert
        assertEquals(Long.MIN_VALUE, counterManager.getCounter(), "Counter should handle minimum long value");
    }
    
    @Test
    @DisplayName("Should maintain counter state between calls")
    void testCounterStatePersistence() {
        // Arrange
        long firstValue = 100L;
        long secondValue = 200L;
        
        // Act
        counterManager.setCounter(firstValue);
        assertEquals(firstValue, counterManager.getCounter());
        
        counterManager.setCounter(secondValue);
        assertEquals(secondValue, counterManager.getCounter());
    }
}