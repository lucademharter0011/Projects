package com.example.demo.Exceptions;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Custom Exceptions Tests")
class CustomExceptionsTest {
    
    // SceneSwitchException Tests
    @Test
    @DisplayName("Should create SceneSwitchException with message")
    void testSceneSwitchExceptionWithMessage() {
        // Arrange
        String expectedMessage = "Scene switch failed";
        
        // Act
        SceneSwitchException exception = new SceneSwitchException(expectedMessage);
        
        // Assert
        assertEquals(expectedMessage, exception.getMessage(), "Exception message should match");
        assertNull(exception.getCause(), "Exception should have no cause");
    }
    
    @Test
    @DisplayName("Should create SceneSwitchException with message and cause")
    void testSceneSwitchExceptionWithMessageAndCause() {
        // Arrange
        String expectedMessage = "Scene switch failed";
        Throwable expectedCause = new RuntimeException("Root cause");
        
        // Act
        SceneSwitchException exception = new SceneSwitchException(expectedMessage, expectedCause);
        
        // Assert
        assertEquals(expectedMessage, exception.getMessage(), "Exception message should match");
        assertEquals(expectedCause, exception.getCause(), "Exception cause should match");
    }
    
    @Test
    @DisplayName("Should throw SceneSwitchException correctly")
    void testThrowSceneSwitchException() {
        // Act & Assert
        SceneSwitchException exception = assertThrows(SceneSwitchException.class, () -> {
            throw new SceneSwitchException("Test exception");
        }, "Should throw SceneSwitchException");
        
        assertEquals("Test exception", exception.getMessage(), "Thrown exception should have correct message");
    }
    
    // PanelLoadException Tests
    @Test
    @DisplayName("Should create PanelLoadException with message")
    void testPanelLoadExceptionWithMessage() {
        // Arrange
        String expectedMessage = "Panel load failed";
        
        // Act
        PanelLoadException exception = new PanelLoadException(expectedMessage);
        
        // Assert
        assertEquals(expectedMessage, exception.getMessage(), "Exception message should match");
        assertNull(exception.getCause(), "Exception should have no cause");
    }
    
    @Test
    @DisplayName("Should create PanelLoadException with message and cause")
    void testPanelLoadExceptionWithMessageAndCause() {
        // Arrange
        String expectedMessage = "Panel load failed";
        Throwable expectedCause = new IllegalArgumentException("Invalid panel");
        
        // Act
        PanelLoadException exception = new PanelLoadException(expectedMessage, expectedCause);
        
        // Assert
        assertEquals(expectedMessage, exception.getMessage(), "Exception message should match");
        assertEquals(expectedCause, exception.getCause(), "Exception cause should match");
    }
    
    @Test
    @DisplayName("Should throw PanelLoadException correctly")
    void testThrowPanelLoadException() {
        // Act & Assert
        PanelLoadException exception = assertThrows(PanelLoadException.class, () -> {
            throw new PanelLoadException("Panel loading error");
        }, "Should throw PanelLoadException");
        
        assertEquals("Panel loading error", exception.getMessage(), "Thrown exception should have correct message");
    }
    
    // PurchaseException Tests
    @Test
    @DisplayName("Should create PurchaseException with message")
    void testPurchaseExceptionWithMessage() {
        // Arrange
        String expectedMessage = "Purchase failed";
        
        // Act
        PurchaseException exception = new PurchaseException(expectedMessage);
        
        // Assert
        assertEquals(expectedMessage, exception.getMessage(), "Exception message should match");
        assertNull(exception.getCause(), "Exception should have no cause");
    }
    
    @Test
    @DisplayName("Should create PurchaseException with message and cause")
    void testPurchaseExceptionWithMessageAndCause() {
        // Arrange
        String expectedMessage = "Purchase failed";
        Throwable expectedCause = new IllegalStateException("Insufficient funds");
        
        // Act
        PurchaseException exception = new PurchaseException(expectedMessage, expectedCause);
        
        // Assert
        assertEquals(expectedMessage, exception.getMessage(), "Exception message should match");
        assertEquals(expectedCause, exception.getCause(), "Exception cause should match");
    }
    
    @Test
    @DisplayName("Should throw PurchaseException correctly")
    void testThrowPurchaseException() {
        // Act & Assert
        PurchaseException exception = assertThrows(PurchaseException.class, () -> {
            throw new PurchaseException("Not enough cookies");
        }, "Should throw PurchaseException");
        
        assertEquals("Not enough cookies", exception.getMessage(), "Thrown exception should have correct message");
    }
    
    // SoundManagerException Tests
    @Test
    @DisplayName("Should create SoundManagerException with message")
    void testSoundManagerExceptionWithMessage() {
        // Arrange
        String expectedMessage = "Sound manager error";
        
        // Act
        SoundManagerException exception = new SoundManagerException(expectedMessage);
        
        // Assert
        assertEquals(expectedMessage, exception.getMessage(), "Exception message should match");
        assertNull(exception.getCause(), "Exception should have no cause");
    }
    
    @Test
    @DisplayName("Should create SoundManagerException with message and cause")
    void testSoundManagerExceptionWithMessageAndCause() {
        // Arrange
        String expectedMessage = "Sound manager error";
        Throwable expectedCause = new RuntimeException("Audio device not found");
        
        // Act
        SoundManagerException exception = new SoundManagerException(expectedMessage, expectedCause);
        
        // Assert
        assertEquals(expectedMessage, exception.getMessage(), "Exception message should match");
        assertEquals(expectedCause, exception.getCause(), "Exception cause should match");
    }
    
    @Test
    @DisplayName("Should throw SoundManagerException correctly")
    void testThrowSoundManagerException() {
        // Act & Assert
        SoundManagerException exception = assertThrows(SoundManagerException.class, () -> {
            throw new SoundManagerException("Invalid sound index");
        }, "Should throw SoundManagerException");
        
        assertEquals("Invalid sound index", exception.getMessage(), "Thrown exception should have correct message");
    }
    
    // TimernotFoundException Tests
    @Test
    @DisplayName("Should create TimernotFoundException with message")
    void testTimernotFoundExceptionWithMessage() {
        // Arrange
        String expectedMessage = "Timer not found";
        
        // Act
        TimernotFoundException exception = new TimernotFoundException(expectedMessage);
        
        // Assert
        assertEquals(expectedMessage, exception.getMessage(), "Exception message should match");
        assertNull(exception.getCause(), "Exception should have no cause");
    }
    
    @Test
    @DisplayName("Should create TimernotFoundException with message and cause")
    void testTimernotFoundExceptionWithMessageAndCause() {
        // Arrange
        String expectedMessage = "Timer not found";
        Throwable expectedCause = new IllegalArgumentException("Invalid timer name");
        
        // Act
        TimernotFoundException exception = new TimernotFoundException(expectedMessage, expectedCause);
        
        // Assert
        assertEquals(expectedMessage, exception.getMessage(), "Exception message should match");
        assertEquals(expectedCause, exception.getCause(), "Exception cause should match");
    }
    
    @Test
    @DisplayName("Should throw TimernotFoundException correctly")
    void testThrowTimernotFoundException() {
        // Act & Assert
        TimernotFoundException exception = assertThrows(TimernotFoundException.class, () -> {
            throw new TimernotFoundException("Timer 'unknown' not found");
        }, "Should throw TimernotFoundException");
        
        assertEquals("Timer 'unknown' not found", exception.getMessage(), "Thrown exception should have correct message");
    }
    
    // General Exception Tests
    @Test
    @DisplayName("All custom exceptions should extend Exception")
    void testCustomExceptionsInheritance() {
        // Act
        SceneSwitchException sceneException = new SceneSwitchException("test");
        PanelLoadException panelException = new PanelLoadException("test");
        PurchaseException purchaseException = new PurchaseException("test");
        SoundManagerException soundException = new SoundManagerException("test");
        TimernotFoundException timerException = new TimernotFoundException("test");
        
        // Assert
        assertTrue(sceneException instanceof Exception, "SceneSwitchException should extend Exception");
        assertTrue(panelException instanceof Exception, "PanelLoadException should extend Exception");
        assertTrue(purchaseException instanceof Exception, "PurchaseException should extend Exception");
        assertTrue(soundException instanceof Exception, "SoundManagerException should extend Exception");
        assertTrue(timerException instanceof Exception, "TimernotFoundException should extend Exception");
    }
    
    @Test
    @DisplayName("Should handle null messages gracefully")
    void testNullMessages() {
        // Act & Assert - should not throw exceptions when creating with null message
        assertDoesNotThrow(() -> new SceneSwitchException(null), "Should handle null message for SceneSwitchException");
        assertDoesNotThrow(() -> new PanelLoadException(null), "Should handle null message for PanelLoadException");
        assertDoesNotThrow(() -> new PurchaseException(null), "Should handle null message for PurchaseException");
        assertDoesNotThrow(() -> new SoundManagerException(null), "Should handle null message for SoundManagerException");
        assertDoesNotThrow(() -> new TimernotFoundException(null), "Should handle null message for TimernotFoundException");
    }
    
    @Test
    @DisplayName("Should handle null causes gracefully")
    void testNullCauses() {
        // Act & Assert - should not throw exceptions when creating with null cause
        assertDoesNotThrow(() -> new SceneSwitchException("message", null), "Should handle null cause for SceneSwitchException");
        assertDoesNotThrow(() -> new PanelLoadException("message", null), "Should handle null cause for PanelLoadException");
        assertDoesNotThrow(() -> new PurchaseException("message", null), "Should handle null cause for PurchaseException");
        assertDoesNotThrow(() -> new SoundManagerException("message", null), "Should handle null cause for SoundManagerException");
        assertDoesNotThrow(() -> new TimernotFoundException("message", null), "Should handle null cause for TimernotFoundException");
    }
    
    @Test
    @DisplayName("Should handle empty string messages")
    void testEmptyStringMessages() {
        // Act
        SceneSwitchException sceneException = new SceneSwitchException("");
        PanelLoadException panelException = new PanelLoadException("");
        PurchaseException purchaseException = new PurchaseException("");
        SoundManagerException soundException = new SoundManagerException("");
        TimernotFoundException timerException = new TimernotFoundException("");
        
        // Assert
        assertEquals("", sceneException.getMessage(), "Should preserve empty string message");
        assertEquals("", panelException.getMessage(), "Should preserve empty string message");
        assertEquals("", purchaseException.getMessage(), "Should preserve empty string message");
        assertEquals("", soundException.getMessage(), "Should preserve empty string message");
        assertEquals("", timerException.getMessage(), "Should preserve empty string message");
    }
}