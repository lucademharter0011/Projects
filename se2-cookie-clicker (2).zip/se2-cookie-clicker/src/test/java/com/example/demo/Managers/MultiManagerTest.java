package com.example.demo.Managers;

import com.example.demo.Factory.IObtainble;
import com.example.demo.Factory.ObtainbleFactory;
import com.example.demo.Factory.Typ;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

@DisplayName("MultiManager Tests")
class MultiManagerTest {
    
    private MultiManager multiManager;
    
    @BeforeEach
    void setUp() {
        multiManager = new MultiManager();
    }
    
    @Test
    @DisplayName("Should return zero for empty list")
    void testMultiplyEmptyList() {
        // Arrange
        List<IObtainble> emptyList = new ArrayList<>();
        
        // Act
        int result = multiManager.multiply(emptyList);
        
        // Assert
        assertEquals(0, result, "Empty list should return multiplier of 0");
    }
    
    @Test
    @DisplayName("Should return zero for list with only inactive upgrades")
    void testMultiplyInactiveUpgrades() {
        // Arrange
        List<IObtainble> upgrades = new ArrayList<>();
        upgrades.add(ObtainbleFactory.create(5, false, "Inactive Upgrade 1", "Test1", 25, Typ.Upgrade));
        upgrades.add(ObtainbleFactory.create(10, false, "Inactive Upgrade 2", "Test2", 50, Typ.Upgrade));
        
        // Act
        int result = multiManager.multiply(upgrades);
        
        // Assert
        assertEquals(0, result, "Inactive upgrades should not contribute to multiplier");
    }
    
    @Test
    @DisplayName("Should calculate correct multiplier for active upgrades")
    void testMultiplyActiveUpgrades() {
        // Arrange
        List<IObtainble> upgrades = new ArrayList<>();
        upgrades.add(ObtainbleFactory.create(3, true, "Active Upgrade 1", "Test1", 25, Typ.Upgrade));
        upgrades.add(ObtainbleFactory.create(7, true, "Active Upgrade 2", "Test2", 50, Typ.Upgrade));
        upgrades.add(ObtainbleFactory.create(2, true, "Active Upgrade 3", "Test3", 75, Typ.Upgrade));
        
        // Act
        int result = multiManager.multiply(upgrades);
        
        // Assert
        assertEquals(12, result, "Should sum all active upgrade values (3 + 7 + 2 = 12)");
    }
    
    @Test
    @DisplayName("Should handle mixed active and inactive upgrades")
    void testMultiplyMixedUpgrades() {
        // Arrange
        List<IObtainble> upgrades = new ArrayList<>();
        upgrades.add(ObtainbleFactory.create(4, true, "Active Upgrade", "Active", 25, Typ.Upgrade));
        upgrades.add(ObtainbleFactory.create(8, false, "Inactive Upgrade", "Inactive", 50, Typ.Upgrade));
        upgrades.add(ObtainbleFactory.create(6, true, "Another Active", "Active2", 75, Typ.Upgrade));
        
        // Act
        int result = multiManager.multiply(upgrades);
        
        // Assert
        assertEquals(10, result, "Should only sum active upgrades (4 + 6 = 10)");
    }
    
    @Test
    @DisplayName("Should handle null elements in list")
    void testMultiplyWithNullElements() {
        // Arrange
        List<IObtainble> upgrades = new ArrayList<>();
        upgrades.add(null);
        upgrades.add(ObtainbleFactory.create(5, true, "Active Upgrade", "Test", 25, Typ.Upgrade));
        upgrades.add(null);
        upgrades.add(ObtainbleFactory.create(3, true, "Another Active", "Test2", 50, Typ.Upgrade));
        
        // Act
        int result = multiManager.multiply(upgrades);
        
        // Assert
        assertEquals(8, result, "Should ignore null elements and sum valid active upgrades (5 + 3 = 8)");
    }
    
    @Test
    @DisplayName("Should handle null list gracefully")
    void testMultiplyNullList() {
        // Act & Assert
        assertThrows(NullPointerException.class, () -> {
            multiManager.multiply(null);
        }, "Should throw NullPointerException for null list");
    }
    
    @Test
    @DisplayName("Should handle upgrades with zero values")
    void testMultiplyZeroValues() {
        // Arrange
        List<IObtainble> upgrades = new ArrayList<>();
        upgrades.add(ObtainbleFactory.create(0, true, "Zero Value Upgrade", "Zero", 25, Typ.Upgrade));
        upgrades.add(ObtainbleFactory.create(5, true, "Normal Upgrade", "Normal", 50, Typ.Upgrade));
        
        // Act
        int result = multiManager.multiply(upgrades);
        
        // Assert
        assertEquals(5, result, "Should include zero values in calculation (0 + 5 = 5)");
    }
    
    @Test
    @DisplayName("Should handle upgrades with negative values")
    void testMultiplyNegativeValues() {
        // Arrange
        List<IObtainble> upgrades = new ArrayList<>();
        upgrades.add(ObtainbleFactory.create(-3, true, "Negative Upgrade", "Negative", 25, Typ.Upgrade));
        upgrades.add(ObtainbleFactory.create(8, true, "Positive Upgrade", "Positive", 50, Typ.Upgrade));
        
        // Act
        int result = multiManager.multiply(upgrades);
        
        // Assert
        assertEquals(5, result, "Should handle negative values correctly (-3 + 8 = 5)");
    }
    
    @Test
    @DisplayName("Should handle large number of upgrades")
    void testMultiplyLargeList() {
        // Arrange
        List<IObtainble> upgrades = new ArrayList<>();
        int expectedSum = 0;
        for (int i = 1; i <= 100; i++) {
            upgrades.add(ObtainbleFactory.create(i, true, "Upgrade " + i, "Test" + i, i * 10, Typ.Upgrade));
            expectedSum += i;
        }
        
        // Act
        int result = multiManager.multiply(upgrades);
        
        // Assert
        assertEquals(expectedSum, result, "Should handle large lists correctly");
        assertEquals(5050, result, "Sum of 1-100 should be 5050");
    }
    
    @Test
    @DisplayName("Should work with achievements as well as upgrades")
    void testMultiplyWithAchievements() {
        // Arrange
        List<IObtainble> items = new ArrayList<>();
        items.add(ObtainbleFactory.create(2, true, "Active Achievement", "Achievement", 0, Typ.Achievement));
        items.add(ObtainbleFactory.create(3, true, "Active Upgrade", "Upgrade", 25, Typ.Upgrade));
        
        // Act
        int result = multiManager.multiply(items);
        
        // Assert
        assertEquals(5, result, "Should work with both achievements and upgrades (2 + 3 = 5)");
    }
}