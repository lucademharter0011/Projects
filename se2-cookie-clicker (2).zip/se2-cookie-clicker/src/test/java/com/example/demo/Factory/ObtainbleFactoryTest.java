package com.example.demo.Factory;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

@DisplayName("ObtainbleFactory Tests")
class ObtainbleFactoryTest {
    
    @Test
    @DisplayName("Should create Upgrade correctly")
    void testCreateUpgrade() {
        // Arrange
        int value = 5;
        boolean status = false;
        String description = "Test upgrade description";
        String name = "Test Upgrade";
        int cost = 100;
        
        // Act
        IObtainble upgrade = ObtainbleFactory.create(value, status, description, name, cost, Typ.Upgrade);
        
        // Assert
        assertNotNull(upgrade, "Created upgrade should not be null");
        assertEquals(value, upgrade.getValue(), "Upgrade value should match");
        assertEquals(status, upgrade.getStatus(), "Upgrade status should match");
        assertEquals(description, upgrade.getDescription(), "Upgrade description should match");
        assertEquals(name, upgrade.getName(), "Upgrade name should match");
        assertEquals(cost, upgrade.getCost(), "Upgrade cost should match");
    }
    
    @Test
    @DisplayName("Should create Achievement correctly")
    void testCreateAchievement() {
        // Arrange
        int value = 10;
        boolean status = true;
        String description = "Test achievement description";
        String name = "Test Achievement";
        int cost = 0; // Achievements typically have no cost
        
        // Act
        IObtainble achievement = ObtainbleFactory.create(value, status, description, name, cost, Typ.Achievement);
        
        // Assert
        assertNotNull(achievement, "Created achievement should not be null");
        assertEquals(value, achievement.getValue(), "Achievement value should match");
        assertEquals(status, achievement.getStatus(), "Achievement status should match");
        assertEquals(description, achievement.getDescription(), "Achievement description should match");
        assertEquals(name, achievement.getName(), "Achievement name should match");
        assertEquals(0, achievement.getCost(), "Achievement cost should be 0");
    }
    
    @Test
    @DisplayName("Should return null for invalid type")
    void testCreateWithInvalidType() {
        // Act
        IObtainble result = ObtainbleFactory.create(5, false, "Description", "Name", 25, null);
        
        // Assert
        assertNull(result, "Factory should return null for invalid type");
    }
    
    @Test
    @DisplayName("Should handle zero values correctly")
    void testCreateWithZeroValues() {
        // Act
        IObtainble upgrade = ObtainbleFactory.create(0, false, "", "", 0, Typ.Upgrade);
        
        // Assert
        assertNotNull(upgrade, "Should create upgrade with zero values");
        assertEquals(0, upgrade.getValue(), "Zero value should be preserved");
        assertEquals("", upgrade.getDescription(), "Empty description should be preserved");
        assertEquals("", upgrade.getName(), "Empty name should be preserved");
        assertEquals(0, upgrade.getCost(), "Zero cost should be preserved");
    }
    
    @Test
    @DisplayName("Should handle negative values correctly")
    void testCreateWithNegativeValues() {
        // Act
        IObtainble upgrade = ObtainbleFactory.create(-5, true, "Negative upgrade", "Negative", -10, Typ.Upgrade);
        
        // Assert
        assertNotNull(upgrade, "Should create upgrade with negative values");
        assertEquals(-5, upgrade.getValue(), "Negative value should be preserved");
        assertEquals(-10, upgrade.getCost(), "Negative cost should be preserved");
    }
    
    @Test
    @DisplayName("Should handle null strings correctly")
    void testCreateWithNullStrings() {
        // Act
        IObtainble upgrade = ObtainbleFactory.create(5, false, null, null, 25, Typ.Upgrade);
        
        // Assert
        assertNotNull(upgrade, "Should create upgrade with null strings");
        assertNull(upgrade.getDescription(), "Null description should be preserved");
        assertNull(upgrade.getName(), "Null name should be preserved");
    }
    
    @Test
    @DisplayName("Should handle maximum integer values")
    void testCreateWithMaxValues() {
        // Act
        IObtainble upgrade = ObtainbleFactory.create(Integer.MAX_VALUE, true, "Max upgrade", "Max", Integer.MAX_VALUE, Typ.Upgrade);
        
        // Assert
        assertNotNull(upgrade, "Should create upgrade with maximum values");
        assertEquals(Integer.MAX_VALUE, upgrade.getValue(), "Maximum value should be preserved");
        assertEquals(Integer.MAX_VALUE, upgrade.getCost(), "Maximum cost should be preserved");
    }
    
    @Test
    @DisplayName("Should handle minimum integer values")
    void testCreateWithMinValues() {
        // Act
        IObtainble upgrade = ObtainbleFactory.create(Integer.MIN_VALUE, false, "Min upgrade", "Min", Integer.MIN_VALUE, Typ.Upgrade);
        
        // Assert
        assertNotNull(upgrade, "Should create upgrade with minimum values");
        assertEquals(Integer.MIN_VALUE, upgrade.getValue(), "Minimum value should be preserved");
        assertEquals(Integer.MIN_VALUE, upgrade.getCost(), "Minimum cost should be preserved");
    }
    
    @Test
    @DisplayName("Should create multiple different objects")
    void testCreateMultipleObjects() {
        // Act
        IObtainble upgrade1 = ObtainbleFactory.create(1, false, "Upgrade 1", "U1", 10, Typ.Upgrade);
        IObtainble upgrade2 = ObtainbleFactory.create(2, true, "Upgrade 2", "U2", 20, Typ.Upgrade);
        IObtainble achievement1 = ObtainbleFactory.create(3, false, "Achievement 1", "A1", 0, Typ.Achievement);
        IObtainble achievement2 = ObtainbleFactory.create(4, true, "Achievement 2", "A2", 0, Typ.Achievement);
        
        // Assert
        assertNotSame(upgrade1, upgrade2, "Different upgrade objects should be created");
        assertNotSame(achievement1, achievement2, "Different achievement objects should be created");
        assertNotSame(upgrade1, achievement1, "Upgrades and achievements should be different objects");
        
        // Verify each object has correct properties
        assertEquals(1, upgrade1.getValue());
        assertEquals(2, upgrade2.getValue());
        assertEquals(3, achievement1.getValue());
        assertEquals(4, achievement2.getValue());
    }
    
    @Test
    @DisplayName("Should handle very long strings")
    void testCreateWithLongStrings() {
        // Arrange
        String longDescription = "A".repeat(1000);
        String longName = "B".repeat(500);
        
        // Act
        IObtainble upgrade = ObtainbleFactory.create(5, false, longDescription, longName, 25, Typ.Upgrade);
        
        // Assert
        assertNotNull(upgrade, "Should create upgrade with long strings");
        assertEquals(longDescription, upgrade.getDescription(), "Long description should be preserved");
        assertEquals(longName, upgrade.getName(), "Long name should be preserved");
    }
}