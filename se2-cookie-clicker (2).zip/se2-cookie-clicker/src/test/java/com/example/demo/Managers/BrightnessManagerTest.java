package com.example.demo.Managers;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

@DisplayName("BrightnessManager Tests")
class BrightnessManagerTest {
    
    private BrightnessManager brightnessManager;
    
    @BeforeEach
    void setUp() {
        brightnessManager = BrightnessManager.getInstance();
        brightnessManager.setBrightness(0.0); // Reset to default for each test
    }
    
    @Test
    @DisplayName("Should create singleton instance")
    void testSingletonPattern() {
        BrightnessManager instance1 = BrightnessManager.getInstance();
        BrightnessManager instance2 = BrightnessManager.getInstance();
        
        assertSame(instance1, instance2, "Both instances should be the same (Singleton)");
    }
    
    @Test
    @DisplayName("Should initialize with default brightness")
    void testDefaultBrightnessInitialization() {
        BrightnessManager newManager = BrightnessManager.getInstance();
        // After reset in setUp, brightness should be 0.0
        assertEquals(0.0, newManager.getBrightness(), 0.001, "Default brightness should be 0.0");
    }
    
    @Test
    @DisplayName("Should set and get brightness correctly")
    void testSetAndGetBrightness() {
        // Arrange
        double expectedBrightness = 0.75;
        
        // Act
        brightnessManager.setBrightness(expectedBrightness);
        double actualBrightness = brightnessManager.getBrightness();
        
        // Assert
        assertEquals(expectedBrightness, actualBrightness, 0.001, "Brightness value should match set value");
    }
    
    @Test
    @DisplayName("Should handle minimum brightness value")
    void testMinimumBrightness() {
        // Act
        brightnessManager.setBrightness(-1.0);
        
        // Assert
        assertEquals(-1.0, brightnessManager.getBrightness(), 0.001, "Should handle minimum brightness value");
    }
    
    @Test
    @DisplayName("Should handle maximum brightness value")
    void testMaximumBrightness() {
        // Act
        brightnessManager.setBrightness(1.0);
        
        // Assert
        assertEquals(1.0, brightnessManager.getBrightness(), 0.001, "Should handle maximum brightness value");
    }
    
    @Test
    @DisplayName("Should handle zero brightness")
    void testZeroBrightness() {
        // Act
        brightnessManager.setBrightness(0.0);
        
        // Assert
        assertEquals(0.0, brightnessManager.getBrightness(), 0.001, "Should handle zero brightness");
    }
    
    @Test
    @DisplayName("Should handle negative brightness values")
    void testNegativeBrightness() {
        // Act
        brightnessManager.setBrightness(-0.5);
        
        // Assert
        assertEquals(-0.5, brightnessManager.getBrightness(), 0.001, "Should handle negative brightness values");
    }
    
    @Test
    @DisplayName("Should handle fractional brightness values")
    void testFractionalBrightness() {
        // Act
        brightnessManager.setBrightness(0.333);
        
        // Assert
        assertEquals(0.333, brightnessManager.getBrightness(), 0.001, "Should handle fractional brightness values");
    }
    
    @Test
    @DisplayName("Should handle extreme double values")
    void testExtremeBrightnessValues() {
        // Test very large value
        brightnessManager.setBrightness(Double.MAX_VALUE);
        assertEquals(Double.MAX_VALUE, brightnessManager.getBrightness(), "Should handle maximum double value");
        
        // Test very small value
        brightnessManager.setBrightness(Double.MIN_VALUE);
        assertEquals(Double.MIN_VALUE, brightnessManager.getBrightness(), "Should handle minimum double value");
        
        // Test negative maximum
        brightnessManager.setBrightness(-Double.MAX_VALUE);
        assertEquals(-Double.MAX_VALUE, brightnessManager.getBrightness(), "Should handle negative maximum double value");
    }
    
    @Test
    @DisplayName("Should handle special double values")
    void testSpecialDoubleValues() {
        // Test NaN
        brightnessManager.setBrightness(Double.NaN);
        assertTrue(Double.isNaN(brightnessManager.getBrightness()), "Should handle NaN value");
        
        // Test positive infinity
        brightnessManager.setBrightness(Double.POSITIVE_INFINITY);
        assertEquals(Double.POSITIVE_INFINITY, brightnessManager.getBrightness(), "Should handle positive infinity");
        
        // Test negative infinity
        brightnessManager.setBrightness(Double.NEGATIVE_INFINITY);
        assertEquals(Double.NEGATIVE_INFINITY, brightnessManager.getBrightness(), "Should handle negative infinity");
    }
    
    @Test
    @DisplayName("Should maintain brightness state between calls")
    void testBrightnessStatePersistence() {
        // Arrange
        double firstValue = 0.25;
        double secondValue = 0.85;
        
        // Act & Assert
        brightnessManager.setBrightness(firstValue);
        assertEquals(firstValue, brightnessManager.getBrightness(), 0.001, "First brightness value should be maintained");
        
        brightnessManager.setBrightness(secondValue);
        assertEquals(secondValue, brightnessManager.getBrightness(), 0.001, "Second brightness value should be maintained");
    }
    
    @Test
    @DisplayName("Should handle rapid brightness changes")
    void testRapidBrightnessChanges() {
        // Act & Assert - rapid successive changes
        for (int i = 0; i < 100; i++) {
            double value = i / 100.0;
            brightnessManager.setBrightness(value);
            assertEquals(value, brightnessManager.getBrightness(), 0.001, 
                "Brightness should be correctly set on iteration " + i);
        }
    }
    
    @Test
    @DisplayName("Should handle precision of brightness values")
    void testBrightnessPrecision() {
        // Test very precise values
        double preciseValue = 0.123456789;
        brightnessManager.setBrightness(preciseValue);
        
        assertEquals(preciseValue, brightnessManager.getBrightness(), 0.000000001, 
            "Should maintain precision of brightness values");
    }
}