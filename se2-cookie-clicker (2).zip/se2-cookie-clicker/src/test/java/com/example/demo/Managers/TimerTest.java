package com.example.demo.Managers;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Timer Tests")
class TimerTest {
    
    private Timer timer;
    
    @BeforeEach
    void setUp() {
        timer = new Timer("TestTimer");
    }
    
    @Test
    @DisplayName("Should create timer with correct name")
    void testTimerCreation() {
        // Timer creation is tested implicitly through other tests
        // since we can't directly access the name field
        assertNotNull(timer, "Timer should be created successfully");
    }
    
    @Test
    @DisplayName("Should initialize with zero seconds")
    void testInitialSeconds() {
        assertEquals(0, timer.getSeconds(), "Timer should start with 0 seconds");
    }
    
    @Test
    @DisplayName("Should initialize as not running")
    void testInitialState() {
        assertFalse(timer.isOn(), "Timer should initially be off");
    }
    
    @Test
    @DisplayName("Should start timer correctly")
    void testStartTimer() {
        // Act
        timer.start();
        
        // Assert
        assertTrue(timer.isOn(), "Timer should be on after starting");
    }
    
    @Test
    @DisplayName("Should not start timer multiple times")
    void testStartTimerMultipleTimes() {
        // Act
        timer.start();
        boolean firstStartState = timer.isOn();
        timer.start(); // Try to start again
        boolean secondStartState = timer.isOn();
        
        // Assert
        assertTrue(firstStartState, "Timer should be on after first start");
        assertTrue(secondStartState, "Timer should remain on after second start attempt");
    }
    
    @Test
    @DisplayName("Should stop timer correctly")
    void testStopTimer() {
        // Arrange
        timer.start();
        
        // Act
        timer.stopTimer();
        
        // Assert
        assertFalse(timer.isOn(), "Timer should be off after stopping");
    }
    
    @Test
    @DisplayName("Should reset timer seconds")
    void testResetTimer() throws InterruptedException {
        // Arrange
        timer.start();
        Thread.sleep(1100); // Wait for at least 1 second to increment
        
        // Act
        timer.reset();
        
        // Assert
        assertEquals(0, timer.getSeconds(), "Timer seconds should be reset to 0");
    }
    
    @Test
    @DisplayName("Should reset timer while running")
    void testResetRunningTimer() throws InterruptedException {
        // Arrange
        timer.start();
        Thread.sleep(1100); // Wait for increment
        
        // Act
        timer.reset();
        
        // Assert
        assertEquals(0, timer.getSeconds(), "Running timer seconds should reset to 0");
        assertTrue(timer.isOn(), "Timer should still be running after reset");
    }
    
    @Test
    @DisplayName("Should increment seconds when running")
    void testSecondsIncrement() throws InterruptedException {
        // Arrange
        timer.start();
        
        // Act
        Thread.sleep(2200); // Wait for approximately 2 seconds
        
        // Assert
        int seconds = timer.getSeconds();
        assertTrue(seconds >= 1, "Timer should have incremented at least 1 second");
        assertTrue(seconds <= 3, "Timer should not have incremented more than 3 seconds");
        
        // Clean up
        timer.stopTimer();
    }
    
    @Test
    @DisplayName("Should not increment seconds when not running")
    void testSecondsNoIncrementWhenStopped() throws InterruptedException {
        // Act
        Thread.sleep(1100); // Wait without starting timer
        
        // Assert
        assertEquals(0, timer.getSeconds(), "Stopped timer should not increment seconds");
    }
    
    @Test
    @DisplayName("Should handle stop when not running")
    void testStopWhenNotRunning() {
        // Act & Assert - should not throw exception
        assertDoesNotThrow(() -> timer.stopTimer(), "Stopping non-running timer should not throw exception");
        assertFalse(timer.isOn(), "Timer should remain off");
    }
    
    @Test
    @DisplayName("Should handle reset when not running")
    void testResetWhenNotRunning() {
        // Act & Assert - should not throw exception
        assertDoesNotThrow(() -> timer.reset(), "Resetting non-running timer should not throw exception");
        assertEquals(0, timer.getSeconds(), "Reset should set seconds to 0 even when not running");
    }
    
    @Test
    @DisplayName("Should create multiple independent timers")
    void testMultipleTimers() throws InterruptedException {
        // Arrange
        Timer timer1 = new Timer("Timer1");
        Timer timer2 = new Timer("Timer2");
        
        // Act
        timer1.start();
        Thread.sleep(1100); // Let timer1 run
        timer2.start();
        Thread.sleep(1100); // Let both run
        
        // Assert
        int timer1Seconds = timer1.getSeconds();
        int timer2Seconds = timer2.getSeconds();
        
        assertTrue(timer1Seconds >= timer2Seconds, "Timer1 should have more or equal seconds than Timer2");
        assertTrue(timer1.isOn(), "Timer1 should be running");
        assertTrue(timer2.isOn(), "Timer2 should be running");
        
        // Clean up
        timer1.stopTimer();
        timer2.stopTimer();
    }
    
    @Test
    @DisplayName("Should handle concurrent operations")
    void testConcurrentOperations() throws InterruptedException {
        // Arrange
        timer.start();
        
        // Act - simulate concurrent access
        Thread resetThread = new Thread(() -> timer.reset());
        Thread stopThread = new Thread(() -> timer.stopTimer());
        
        resetThread.start();
        stopThread.start();
        
        resetThread.join();
        stopThread.join();
        
        // Assert - should not crash and maintain consistent state
        assertFalse(timer.isOn(), "Timer should be stopped");
        assertEquals(0, timer.getSeconds(), "Timer should be reset");
    }
    
    @Test
    @DisplayName("Should maintain thread safety for getSeconds")
    void testGetSecondsThreadSafety() throws InterruptedException {
        // Arrange
        timer.start();
        Thread.sleep(500); // Let it run briefly
        
        // Act - concurrent reads
        Thread[] readers = new Thread[10];
        int[] results = new int[10];
        
        for (int i = 0; i < 10; i++) {
            final int index = i;
            readers[i] = new Thread(() -> results[index] = timer.getSeconds());
            readers[i].start();
        }
        
        for (Thread reader : readers) {
            reader.join();
        }
        
        timer.stopTimer();
        
        // Assert - all reads should be valid (non-negative)
        for (int result : results) {
            assertTrue(result >= 0, "All second readings should be non-negative");
        }
    }
}