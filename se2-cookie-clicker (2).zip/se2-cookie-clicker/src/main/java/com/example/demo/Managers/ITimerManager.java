package com.example.demo.Managers;

public interface ITimerManager{
    void addTimer(Timer timer);
    void resetTimer(String name);
    void stopTimer(String name);
    boolean active(String name);
    void startTimer(String name);
    int getSeconds(String name);
}
