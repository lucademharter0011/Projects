package com.example.demo.Managers;
import com.example.demo.Factory.IObtainble;

import java.util.List;

public interface IMultipliable {
    int multiply(List<IObtainble>upgrades);
}
