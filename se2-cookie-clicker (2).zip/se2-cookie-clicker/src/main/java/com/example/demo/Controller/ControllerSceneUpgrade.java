package com.example.demo.Controller;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.example.demo.Exceptions.PanelLoadException;
import com.example.demo.Exceptions.SceneSwitchException;
import com.example.demo.Exceptions.SoundManagerException;
import com.example.demo.Factory.IObtainble;
import com.example.demo.Main;
import com.example.demo.Managers.BrightnessManager;
import com.example.demo.Managers.IBright;
import com.example.demo.Managers.ISceneSwitcher;
import com.example.demo.Managers.ITimerManager;
import com.example.demo.Managers.IUListManager;
import com.example.demo.Managers.SceneSwitcher;
import com.example.demo.Managers.Timer;
import com.example.demo.Managers.TimerManager;
import com.example.demo.Managers.UpgradeManager;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;

public class ControllerSceneUpgrade{
    private static final Logger logger= Logger.getLogger(ControllerSceneUpgrade.class.getName());
    ISceneSwitcher manager=SceneSwitcher.getInstance();
    IBright bmanager= BrightnessManager.getInstance();
    IUListManager upgradeManager=UpgradeManager.getInstance();
    ITimerManager tmanager= TimerManager.getInstance();
    Image image = new Image(getClass().getResource("/Images/Checked.png").toExternalForm());
    Image starimage = new Image(getClass().getResource("/Images/Star.png").toExternalForm());
    private final ColorAdjust brightnessEffect = new ColorAdjust();
    @FXML
    VBox UpgradeSammlung = new VBox();
    @FXML
    private Pane rootPane;
    public void timeout(){
        if(tmanager.active("timeouttimer")){
        tmanager.resetTimer("timeouttimer");
        logger.log(Level.INFO,"Cookie wurde verlassen und und Timer wurde zurückgesetzt");
        }
        else{
        tmanager.startTimer("timeouttimer");
            logger.log(Level.INFO, "Timeout Timer wurde gestartet");
        }
    }

    
    public void initialize() {
        brightnessEffect.setBrightness(bmanager.getBrightness());
        rootPane.setEffect(brightnessEffect);
        logger.log(Level.INFO,"ControllerSceneUpgrade wurde initaliziert!");
    }
    
    public void Upgradeadd(){
    List<IObtainble> upgradeList = upgradeManager.getlist();
    try{
        for (IObtainble y : upgradeList) {
            System.out.println("DEBUG: Loading upgrade: " + y.getName());
            FXMLLoader fxmlLoaderUpgradepanel = new FXMLLoader(Main.class.getResource("/fxml-files/UpgradePanel.fxml"));
            Node Node = fxmlLoaderUpgradepanel.load();
            ControllerUpgradePanel controllerUpgradepanel = fxmlLoaderUpgradepanel.getController();
            controllerUpgradepanel.Cost.setText(String.valueOf(y.getCost()));
            controllerUpgradepanel.Description.setText(y.getDescription());
            controllerUpgradepanel.Name.setText(y.getName());
            if(y.getName().equals("")||y.getName().equals("")){
                throw new PanelLoadException("Das Achievementpanel konnte nicht geladen werden, da der Name leer ist.");
            }
            
            if (y.getStatus() && !y.getName().equals("VICTORY")) {
                controllerUpgradepanel.Buy.setImage(image);
                controllerUpgradepanel.Upgradebox.setStyle("-fx-background-color: #35E09D;");
            }
            else if(y.getName().equals("VICTORY")) {
                controllerUpgradepanel.Upgradebox.setStyle("-fx-background-color: #D641DE;");
                controllerUpgradepanel.Buy.setImage(starimage);
            }
            
            
            UpgradeSammlung.getChildren().add(Node);
        }
    } catch (IOException | PanelLoadException e) {
        logger.log(Level.SEVERE, "Fehler beim Laden des UpgradePanels: " + e.getMessage());
    }
    upgradeManager.setlist(upgradeList);
}
public void switchToScene(MouseEvent event) throws SoundManagerException, PanelLoadException {
    Node source=(Node) event.getSource();
    String id=source.getId();
    try {
        if (id.equals("SettingsBild"))manager.switchScene("/fxml-files/SettingScene.fxml");
        else if (id.equals("AchievementBild"))manager.switchScene("/fxml-files/AchievementScene.fxml");
        else if (id.equals("HomeBild"))manager.switchScene("/fxml-files/HomeScene.fxml");
        else{throw new SceneSwitchException("Unbekannte Szene: " + id);}
    } catch (SceneSwitchException e) {
        logger.log(Level.SEVERE,"Fehler beim Wechseln der Szene: " + e.getMessage());
    }
}
}
