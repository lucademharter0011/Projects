package com.example.demo.Managers;

public interface IBright {
    void setBrightness(double brightness);
    double getBrightness();
}
