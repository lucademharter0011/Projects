package com.example.demo.Factory;
public enum Typ {
    Achievement,
    Upgrade
}
