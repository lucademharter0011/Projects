package com.example.demo.Controller;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.example.demo.Exceptions.PanelLoadException;
import com.example.demo.Exceptions.SceneSwitchException;
import com.example.demo.Exceptions.SoundManagerException;
import com.example.demo.Factory.IObtainble;
import com.example.demo.Managers.AchievementManager;
import com.example.demo.Managers.BrightnessManager;
import com.example.demo.Managers.CounterManager;
import com.example.demo.Managers.IAListManager;
import com.example.demo.Managers.IBright;
import com.example.demo.Managers.ICountable;
import com.example.demo.Managers.ISceneSwitcher;
import com.example.demo.Managers.ISoundManager;
import com.example.demo.Managers.ITimerManager;
import com.example.demo.Managers.IUListManager;
import com.example.demo.Managers.SceneSwitcher;
import com.example.demo.Managers.SoundManager;
import com.example.demo.Managers.TimerManager;
import com.example.demo.Managers.UpgradeManager;

import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
public class ControllerSceneHome {
    boolean bonus;
    private static final Logger logger= Logger.getLogger(ControllerSceneHome.class.getName());
    ICountable counterManager=CounterManager.getInstance();
    ISceneSwitcher manager=SceneSwitcher.getInstance();
    IUListManager upgradeManager=UpgradeManager.getInstance();
    IBright bmanager= BrightnessManager.getInstance();
    IAListManager amanger=AchievementManager.getInstance();
    ITimerManager tmanager= TimerManager.getInstance();
    ISoundManager soundManager=SoundManager.getInstance();
    @FXML
    private Label Counter;
    @FXML
    private Pane rootPane;
    private final ColorAdjust brightnessEffect = new ColorAdjust();
    public void initialize(){
        brightnessEffect.setBrightness(bmanager.getBrightness());
        rootPane.setEffect(brightnessEffect);
        Counter.setText(Long.toString(counterManager.getCounter()));
        bonus=false;
        logger.log(Level.INFO,"ControllerHome wurde initaliziert!");
    }
                public void switchToHome(MouseEvent event) {
    try {
        manager.switchScene("/fxml-files/HomeScene.fxml");
    } catch (SoundManagerException | PanelLoadException e) {
        logger.log(Level.SEVERE,"Fehler beim Wechseln zur Home Szene: " + e.getMessage());
    }
    }
public void switchToScene(MouseEvent event) throws SoundManagerException, PanelLoadException {
    timeout();
    Node source=(Node) event.getSource();
    String id=source.getId();
    try {
        if (id.equals("UpgradeBild"))manager.switchScene("/fxml-files/UpgradeScene.fxml");
        else if (id.equals("AchievementBild"))manager.switchScene("/fxml-files/AchievementScene.fxml");
        else if (id.equals("SettingsBild"))manager.switchScene("/fxml-files/SettingScene.fxml");
        else{throw new SceneSwitchException("Unbekannte Szene: " + id);}
    } catch (SceneSwitchException e) {
        logger.log(Level.SEVERE,"Fehler beim Wechseln der Szene: " + e.getMessage());
    }
}
        public void exited(){
        if(tmanager.active("cookietimer")){
            tmanager.stopTimer("cookietimer");
            logger.log(Level.INFO,"Cookie wurde verlassen und Timer wurde zurückgesetzt");
        }
        }
    public void timeout(){
        if(tmanager.active("timeouttimer")){
        tmanager.resetTimer("timeouttimer");
        logger.log(Level.INFO,"Cookie wurde verlassen und und Timer wurde zurückgesetzt");
        }
        else{
        tmanager.startTimer("timeouttimer");
            logger.log(Level.INFO, "Timeout Timer wurde gestartet");
        }
    }

    public void increment() throws SoundManagerException {
        timeout();
        List<IObtainble> achievementliste = amanger.getlist();
        int increment=1;
        if(upgradeManager.domultiply()!=0){
            increment=upgradeManager.domultiply();
        }
        long num=counterManager.getCounter();
        Counter.setText(Long.toString(num+increment));
        counterManager.setCounter(Integer.parseInt(Counter.getText()));
        soundManager.playSound('c');
        logger.log(Level.INFO,"Der Counter beträgt nun: "+counterManager.getCounter());
        if(!tmanager.active("cookietimer")){
            tmanager.startTimer("cookietimer");;
            logger.info("Cookie Timer wurde gestartet.");
        }
        if(tmanager.getSeconds("cookietimer")!=0&&tmanager.getSeconds("cookietimer")%30==0&&!bonus){
            counterManager.setCounter(counterManager.getCounter()+30);
            bonus=true;
            logger.log(Level.INFO,"Counter wurde um 30 erhöht");
        }
    for(IObtainble x:achievementliste){
    if(x.getValue()<=counterManager.getCounter()&&!x.getName().equals("VICTORY")){
        if(!x.getStatus()){
            x.setStatus(true);
            soundManager.playSound('a');
            logger.log(Level.INFO,"Der Status von " + x.getName() +" wurde auf "+x.getStatus()+"gesetzt!" );
        }
    }
        }
        amanger.setlist(achievementliste);
        if(amanger.allactivated()&&upgradeManager.allactivated()){
            amanger.activatevictory();
            upgradeManager.activatevictory();
            logger.log(Level.INFO,"DU HAST GEWONNEN!");
        }
    }
}