package com.example.demo.Managers;

public interface ICountable {
    void setCounter(long value);
    long getCounter();
}
