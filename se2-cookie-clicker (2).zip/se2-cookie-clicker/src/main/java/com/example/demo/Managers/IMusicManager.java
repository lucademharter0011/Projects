package com.example.demo.Managers;

public interface IMusicManager {
    void backgroundMusic();
    void stop();
    void setVolume(double volume);
    double getVolume();
}
