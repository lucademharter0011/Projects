package com.example.demo.Managers;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.example.demo.Exceptions.TimernotFoundException;
public class TimerManager implements ITimerManager{
    private static final Logger logger= Logger.getLogger(TimerManager.class.getName());
    private static TimerManager instance;
    private final List<Timer> timerListe;
    private TimerManager(List<Timer> initialTimers){
        this.timerListe = new ArrayList<>(initialTimers);
    }

    public static TimerManager getInstance() {
        if (instance == null){
            List<Timer> initialTimers = List.of(new Timer("cookietimer"), new Timer("timeouttimer"));
            instance = new TimerManager(initialTimers);
            logger.log(Level.INFO,"Manager wurde erstellt!");

        }
        logger.log(Level.INFO,"Manager wurde zurückgegeben!");
        return instance;
    }
    @Override
    public void addTimer(Timer timer) {
        timerListe.add(timer);
        logger.log(Level.INFO,"Neuer Timer wurde hinzugefügt!");
    }
    @Override
    public boolean active(String name) {
        try{
        if(name.equals("cookietimer")){
            timerListe.get(0).isOn();
            logger.log(Level.INFO,"Cookietimer Sekunden zurückgegeben!");
        }
        else if(name.equals("timeouttimer")){
            timerListe.get(1).isOn();
            logger.log(Level.INFO,"Timeouttimer Sekunden zurückgegeben!");
        }
        else {
            throw new TimernotFoundException("Kein Timer mit dem Namen " + name + " gefunden!");
        }
        } catch (TimernotFoundException e) {
            logger.log(Level.WARNING, "Fehler beim Überprüfen des Timers: " + e.getMessage());
            return false; // oder eine andere Fehlerbehandlung
        }
        return false;
    }
    public void startTimer(String name) {
        try{
        if(name.equals("cookietimer")){
            timerListe.get(0).start();
            logger.log(Level.INFO,"Cookietimer wurde gestartet!");
        }
        else if(name.equals("timeouttimer")){
            timerListe.get(1).start();
            logger.log(Level.INFO,"Timeouttimer wurde gestartet!");
        }
        else {
            throw new TimernotFoundException("Kein Timer mit dem Namen " + name + " gefunden!");
            
        }
        } catch (TimernotFoundException e) {
            logger.log(Level.WARNING, "Fehler beim Starten des Timers: " + e.getMessage());
        }
    }
    public void stopTimer(String name) {
        try{
        if(name.equals("cookietimer")){
            timerListe.get(0).stopTimer();
            logger.log(Level.INFO,"Cookietimer wurde gestoppt!");
        }
        else if(name.equals("timeouttimer")){
            timerListe.get(1).stopTimer();
            logger.log(Level.INFO,"Timeouttimer wurde gestoppt!");
        }
        else {
            throw new TimernotFoundException("Kein Timer mit dem Namen " + name + " gefunden!");
            
        }} catch (TimernotFoundException e) {
            logger.log(Level.WARNING, "Fehler beim Stoppen des Timers: " + e.getMessage());
        }
    }
    public  void resetTimer(String name) {
       try{ 
        if(name.equals("cookietimer")){
                timerListe.get(0).reset();
                logger.log(Level.INFO,"Cookietimer zurückgesetzt!");
        }
        else if(name.equals("timeouttimer")){
            timerListe.get(1).reset();
            logger.log(Level.INFO,"Timeouttimer zurückgesetzt!");
        }
        else {
            throw new TimernotFoundException("Kein Timer mit dem Namen " + name + " gefunden!");
            
        }
        } catch (TimernotFoundException e) {
            logger.log(Level.WARNING, "Fehler beim Zurücksetzen des Timers: " + e.getMessage());
        }
        logger.log(Level.INFO,"Timer wurde zurückgesetzt!");
        }
    @Override
    public int getSeconds(String name) {
        try{
        if(name.equals("cookietimer")){
            logger.log(Level.INFO,"Cookietimer Sekunden zurückgegeben!");
            return timerListe.get(0).getSeconds();
        }
        else if(name.equals("timeouttimer")){
            logger.log(Level.INFO,"Timeouttimer Sekunden zurückgegeben!");
            return timerListe.get(1).getSeconds();
        }
        else {
            throw new TimernotFoundException("Kein Timer mit dem Namen " + name + " gefunden!");
        
        }
        } catch (TimernotFoundException e) {
            logger.log(Level.WARNING, "Fehler beim Abrufen der Sekunden des Timers: " + e.getMessage());
            return -1; // oder eine andere Fehlerbehandlung
        }
    } 
}
