package com.example.demo.Factory;

public interface IObtainble {
    int getValue();
    void setDescription(String description);
    void setValue(int value);
    String getDescription();
    void setStatus(boolean status);
    boolean getStatus();
    String getName();
    void setName(String name);
    int getCost();
}
