package com.example.demo.Exceptions;

public class TimernotFoundException extends Exception {
    public TimernotFoundException(String message) {
        super(message);
    }

    public TimernotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
    
}
