import os

# --- KONFIGURATION ---
ROOT_DIR = r"C:\Users\ludem\email_classifier\TrainingData"
MAX_LENGTH = 1000
# ---------------------

def truncate_emails():
    files_checked = 0
    files_shortened = 0
    
    print(f"Starte Prozess in: {ROOT_DIR}")
    print(f"Ziel: Alle Dateien auf maximal {MAX_LENGTH} Zeichen kürzen.")

    # Rekursiv durch alle Ordner gehen
    for root, dirs, files in os.walk(ROOT_DIR):
        for file in files:
            if file.endswith(".txt"):
                file_path = os.path.join(root, file)
                files_checked += 1
                
                content = ""
                needs_save = False

                # 1. Datei einlesen
                try:
                    # errors='ignore' verhindert Abstürze bei seltsamen Zeichen
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                    
                    # 2. Prüfen: Ist sie zu lang?
                    if len(content) > MAX_LENGTH:
                        # 3. Kürzen (Alles ab Index 1000 wegwerfen)
                        content = content[:MAX_LENGTH]
                        needs_save = True
                        files_shortened += 1
                
                except Exception as e:
                    print(f"Lese-Fehler bei {file}: {e}")
                    continue

                # 4. Datei überschreiben (nur wenn gekürzt wurde)
                if needs_save:
                    try:
                        with open(file_path, 'w', encoding='utf-8') as f:
                            f.write(content)
                    except Exception as e:
                        print(f"Schreib-Fehler bei {file}: {e}")

    print("-" * 30)
    print("FERTIG!")
    print(f"Dateien geprüft: {files_checked}")
    print(f"Dateien gekürzt: {files_shortened}")
    print(f"Dateien unverändert: {files_checked - files_shortened}")

if __name__ == "__main__":
    truncate_emails()