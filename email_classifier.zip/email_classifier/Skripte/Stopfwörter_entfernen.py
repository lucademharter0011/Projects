import os
import re
def remove_stopwords(text):
    """
    Entfernt Zeilenumbrüche, Sonderzeichen und deutsche Stoppwörter.
    """

    # Liste deutscher Stoppwörter
    stop_words = {
        "aber", "alle", "allem", "allen", "aller", "alles", "als", "also", "am", "an",
        "ander", "andere", "anderem", "anderen", "anderer", "anderes", "anderm",
        "andern", "anderr", "anders", "auch", "auf", "aus", "bei", "bin", "bis",
        "bist", "da", "damit", "dann", "der", "den", "des", "dem", "die", "das",
        "dass", "daß", "derselbe", "derselben", "denselben", "derselben", "demselben",
        "dieselbe", "dieselben", "dasselbe", "dazu", "dein", "deine", "deinem",
        "deinen", "deiner", "deines", "denn", "derer", "dessen", "dich", "dir",
        "du", "dies", "diese", "diesem", "diesen", "dieser", "dieses", "doch",
        "dort", "durch", "ein", "eine", "einem", "einen", "einer", "eines", "einig",
        "einige", "einigem", "einigen", "einiger", "einiges", "einmal", "er", "ihn",
        "ihm", "es", "etwas", "euer", "eure", "eurem", "euren", "eurer", "eures",
        "für", "gegen", "gewesen", "hab", "habe", "haben", "hat", "hatte", "hatten",
        "hier", "hin", "hinter", "ich", "mich", "mir", "im", "in", "ist", "ja",
        "jede", "jedem", "jeden", "jeder", "jedes", "jener", "jenem", "jenen",
        "jener", "jenes", "jetzt", "kann", "können", "könnte", "machen", "man",
        "mein", "meine", "meinem", "meinen", "meiner", "meines", "mit", "muss",
        "musste", "nach", "nicht", "nichts", "noch", "nun", "nur", "oder", "seid",
        "sein", "seine", "seinem", "seinen", "seiner", "seines", "selbst", "sich",
        "sie", "ihnen", "sind", "so", "solche", "solchem", "solchen", "solcher",
        "solches", "soll", "sollte", "und", "uns", "unser", "unsere", "unserem",
        "unseren", "unserer", "unseres", "unter", "viel", "vom", "von", "vor",
        "war", "waren", "warst", "was", "weg", "weil", "weiter", "welche", "welchem",
        "welchen", "welcher", "welches", "wenn", "werde", "werden", "wie", "wieder",
        "wir", "wird", "wirst", "wo", "wollen", "wollte", "würde", "würden", "zu",
        "zum", "zur", "zwar", "zwischen"
    }

    cleaned_text = text

    # 1. Formatierung säubern (Zeilenumbrüche entfernen)
    cleaned_text = cleaned_text.replace('\n', ' ').replace('\r', ' ')

    # 2. Sonderzeichen entfernen (Wichtig, damit "und," als "und" erkannt wird)
    cleaned_text = re.sub(r'[^a-zA-Z0-9äöüÄÖÜß ]', '', cleaned_text)

    # 3. Stoppwörter entfernen
    words = cleaned_text.split()
    # word.lower() sorgt dafür, dass "Und" auch gefunden wird, wenn "und" in der Liste ist
    filtered_words = [word for word in words if word.lower() not in stop_words]

    cleaned_text = ' '.join(filtered_words)

    # Mehrfache Leerzeichen normalisieren
    cleaned_text = re.sub(r'\s+', ' ', cleaned_text)

    return cleaned_text.strip()


def process_folder_structure(root_folder_path):
    """
    Durchsucht rekursiv alle Unterordner nach .txt Dateien und bereinigt sie.
    """
    print(f"Starte Verarbeitung in: {root_folder_path}")

    file_counter = 0

    # os.walk geht durch den Hauptordner und alle Unterordner
    for dirpath, dirnames, filenames in os.walk(root_folder_path):
        for filename in filenames:
            if filename.endswith(".txt"):
                file_path = os.path.join(dirpath, filename)

                try:
                    # 1. Datei lesen (UTF-8 ist Standard, falls Fehler auftreten, 'latin-1' probieren)
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()

                    # 2. Text bereinigen
                    new_content = remove_stopwords(content)

                    # 3. Datei überschreiben
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(new_content)

                    print(f"Bereinigt: {filename}")
                    file_counter += 1

                except Exception as e:
                    print(f"Fehler bei Datei {filename}: {e}")

    print(f"\nFertig! Es wurden {file_counter} Dateien bereinigt.")

# --- HAUPTPROGRAMM ---
if __name__ ==  "__main__":
    # HIER DEN PFAD ZU DEINEM HAUPTORDNER EINTRAGEN
    # Beispiel Windows: r"C:\Users\Name\Dokumente\MeinDatenOrdner"
    # Beispiel Mac/Linux: "/home/user/daten"

    mein_ordner_pfad = "C:/Users/User/OneDrive/Studium/Sem_04/SlTAI/email_classifier/TrainingData"
    process_folder_structure(mein_ordner_pfad)